-- ==================================================
-- DATABASE: bisnis_listrik
-- Dibuat oleh: Ardana Project
-- Deskripsi: Sistem Database Bisnis Jasa Listrik
-- ==================================================

CREATE DATABASE IF NOT EXISTS bisnis_listrik;
USE bisnis_listrik;

-- =======================
-- TABEL: pelanggan
-- =======================
CREATE TABLE IF NOT EXISTS pelanggan (
  id_pelanggan INT AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(100) NOT NULL,
  alamat TEXT NOT NULL,
  no_hp VARCHAR(20),
  email VARCHAR(100),
  tanggal_daftar DATE DEFAULT (CURRENT_DATE)
);

-- =======================
-- TABEL: layanan
-- =======================
CREATE TABLE IF NOT EXISTS layanan (
  id_layanan INT AUTO_INCREMENT PRIMARY KEY,
  nama_layanan VARCHAR(100) NOT NULL,
  deskripsi TEXT,
  harga DECIMAL(12,2) NOT NULL
);

-- =======================
-- TABEL: teknisi
-- =======================
CREATE TABLE IF NOT EXISTS teknisi (
  id_teknisi INT AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(100) NOT NULL,
  keahlian VARCHAR(100),
  no_hp VARCHAR(20),
  wilayah VARCHAR(100)
);

-- =======================
-- TABEL: transaksi
-- =======================
CREATE TABLE IF NOT EXISTS transaksi (
  id_transaksi INT AUTO_INCREMENT PRIMARY KEY,
  id_pelanggan INT,
  id_layanan INT,
  id_teknisi INT,
  tanggal DATE DEFAULT (CURRENT_DATE),
  biaya_total DECIMAL(12,2),
  status ENUM('Proses', 'Selesai') DEFAULT 'Proses',
  FOREIGN KEY (id_pelanggan) REFERENCES pelanggan(id_pelanggan) ON DELETE CASCADE,
  FOREIGN KEY (id_layanan) REFERENCES layanan(id_layanan) ON DELETE SET NULL,
  FOREIGN KEY (id_teknisi) REFERENCES teknisi(id_teknisi) ON DELETE SET NULL
);

-- =======================
-- DATA CONTOH
-- =======================
INSERT INTO pelanggan (nama, alamat, no_hp, email, tanggal_daftar) VALUES
('Budi Santoso', 'Jl. Melati No.10, Jakarta', '08123456789', 'budi@gmail.com', '2025-10-01'),
('Siti Rahma', 'Jl. Mawar No.22, Depok', '08213456789', 'siti@yahoo.com', '2025-10-05'),
('Agus Setiawan', 'Jl. Cendana No.7, Bekasi', '08523456789', 'agus@mail.com', '2025-10-08');

INSERT INTO layanan (nama_layanan, deskripsi, harga) VALUES
('Instalasi Baru', 'Pemasangan instalasi listrik rumah baru', 1500000),
('Perbaikan Listrik', 'Perbaikan korsleting dan panel listrik', 500000),
('Audit Energi', 'Pemeriksaan efisiensi energi bangunan', 750000);

INSERT INTO teknisi (nama, keahlian, no_hp, wilayah) VALUES
('Andi Pratama', 'Instalasi & Panel', '081311122233', 'Jakarta Selatan'),
('Rina Dewi', 'Audit Energi', '082233445566', 'Depok'),
('Dedi Kurniawan', 'Perbaikan Rumah Tangga', '085677889900', 'Bekasi');

INSERT INTO transaksi (id_pelanggan, id_layanan, id_teknisi, tanggal, biaya_total, status) VALUES
(1, 1, 1, '2025-10-15', 1500000, 'Selesai'),
(2, 2, 3, '2025-10-20', 500000, 'Selesai'),
(3, 3, 2, '2025-10-22', 750000, 'Proses');

-- ==================================================
-- Database siap digunakan! 🔌
-- ==================================================
